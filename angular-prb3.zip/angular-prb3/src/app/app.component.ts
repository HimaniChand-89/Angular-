import { Component } from "@angular/core";
import { FormControl, FormGroup } from "@angular/forms";
import { GithubService } from "./github.service";

import { repos } from "./repos";

@Component({
  selector: "my-app",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent {
  userName: string = "tektutorialshub";
  repos: repos[];

  loading: boolean = false;
  errorMessage;

  constructor(private githubser: GithubService) {}

  getRepos() {
    this.loading = true;
    this.errorMessage = "";

    this.githubser.getRepo(this.userName).subscribe(response => {
      console.log("Received Response from Observable");
      this.repos = response;
    }),
      error => {
        console.log("Received ERROR from Observable");
        this.errorMessage = error;
        this.loading = false;
      },
      () => {
        console.log("Observable Completed Process");
        this.loading = false;
      };
  }
}
