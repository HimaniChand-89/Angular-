var str = "Hello Programmer's";
function fun() {
    console.log(str);
}
fun();
