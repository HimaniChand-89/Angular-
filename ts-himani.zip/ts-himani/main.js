function log(message);{
    console.log(message);
}
var message = 'Hello Himani';
log(message);
