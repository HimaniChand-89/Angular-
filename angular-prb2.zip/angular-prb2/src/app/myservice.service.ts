import { Injectable } from "@angular/core";
import { IEmployee } from "./employee";

@Injectable()
export class MyserviceService {
  constructor() {}

  getAllEmp(): IEmployee[] {
    return [
      {empId:1001, empName:'Himani', empSalary:23000},
      {empId:1001, empName:'Dolly', empSalary:23000},
      {empId:1001, empName:'Diksha', empSalary:23000},
      {empId:1001, empName:'Anil', empSalary:23000},
      {empId:1001, empName:'Dinesh', empSalary:23000},
      {empId:1001, empName:'Aman', empSalary:23000}

    ];
  }
}
