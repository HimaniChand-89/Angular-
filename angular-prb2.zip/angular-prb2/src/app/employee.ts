import { componentFactoryName } from "@angular/compiler"

export interface IEmployee {
  empId: number;
  empName: String;
  empSalary: number;
}


