import { Component } from "@angular/core";
import { FormControl, FormGroup } from "@angular/forms";
import { IEmployee } from "./employee";
import { MyserviceService } from "./myservice.service";

@Component({
  selector: "my-app",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent {
  employees: IEmployee[];

  constructor(private mySer: MyserviceService) {}
  
  ngOnInit(): void {
    this.employees = this.mySer.getAllEmp();
  }
}
